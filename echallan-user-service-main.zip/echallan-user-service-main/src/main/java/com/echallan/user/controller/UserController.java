package com.echallan.user.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Anilesh Mishra
 *
 */

@RestController
@RequestMapping("/users")
public class UserController {

	
	
}
